Page({
  data: {
    test: '<p><strong>1893年</strong><br />奥斯曼大街上诞生了一间70平米的商铺。在128年间，它发展成为一家7万平方米的大型百货商场。它就是巴黎老佛爷奥斯曼旗舰店。</p>'
  },
  onLoad(options) {
  },
  onShow() {

  },
})